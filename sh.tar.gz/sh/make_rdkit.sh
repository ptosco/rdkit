source $HOME/sh/rdkit_build_env.sh
source ${CONDA}/etc/profile.d/conda.sh
conda activate rdkit_build
cd $HOME/build/rdkit
source $HOME/sh/rdkit_build_env.sh
export SDKROOT="${PWD}/MacOSX${target_platform}.sdk/"
export CONDA_BUILD_SYSROOT=${SDKROOT}
cd build
make -j ${number_of_cores} install

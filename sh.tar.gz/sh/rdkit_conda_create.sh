conda create --name rdkit_build ${compiler} cmake \
  boost-cpp=${boost_version} boost=${boost_version} \
  py-boost=${boost_version} libboost=${boost_version} \
  numpy matplotlib cairo pillow eigen pandas  \
  sphinx=3.1.2 recommonmark jupyter

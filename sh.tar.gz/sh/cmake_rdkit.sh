source $HOME/sh/rdkit_build_env.sh
source ${CONDA}/etc/profile.d/conda.sh
conda activate rdkit_build
cd $HOME/build/rdkit
source $HOME/sh/rdkit_build_env.sh
export SDKROOT="${PWD}/MacOSX${target_platform}.sdk/"
export CONDA_BUILD_SYSROOT=${SDKROOT}
git_branch=`git rev-parse --abbrev-ref HEAD`
mkdir -p build && cd build && rm -f CMakeCache.txt && \
cmake .. \
  -DCMAKE_BUILD_TYPE=Debug \
  -DRDK_INSTALL_INTREE=OFF \
  -DRDK_INSTALL_STATIC_LIBS=OFF \
  -DRDK_BUILD_CPP_TESTS=ON \
  -DRDK_BUILD_PYTHON_WRAPPERS=ON \
  -DRDK_USE_BOOST_REGEX=ON \
  -DRDK_BUILD_COORDGEN_SUPPORT=ON \
  -DRDK_BUILD_MAEPARSER_SUPPORT=ON \
  -DRDK_OPTIMIZE_POPCNT=ON \
  -DRDK_BUILD_TEST_GZIP=ON \
  -DRDK_BUILD_FREESASA_SUPPORT=ON \
  -DRDK_BUILD_AVALON_SUPPORT=ON \
  -DRDK_BUILD_INCHI_SUPPORT=ON \
  -DRDK_BUILD_CAIRO_SUPPORT=ON \
  -DRDK_BUILD_SWIG_WRAPPERS=OFF \
  -DRDK_SWIG_STATIC=OFF \
  -DRDK_BUILD_THREADSAFE_SSS=ON \
  -DRDK_TEST_MULTITHREADED=ON \
  -DBoost_NO_SYSTEM_PATHS=ON \
  -DCMAKE_OSX_SYSROOT=${SDKROOT} \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=${target_platform} \
  -DRDK_BOOST_PYTHON3_NAME=${python_name} \
  -DPYTHON_EXECUTABLE=${CONDA_PREFIX}/bin/python3 \
  -DCMAKE_INCLUDE_PATH="${CONDA_PREFIX}/include" \
  -DCMAKE_LIBRARY_PATH="${CONDA_PREFIX}/lib" \
  -DCMAKE_INSTALL_PREFIX=$HOME/install/rdkit/$git_branch

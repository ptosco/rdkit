export compiler=clangxx_osx-64
export boost_version=1.67.0
export number_of_cores=`sysctl -n hw.ncpu`
export python_name=python37
export target_platform=10.9
export CONDA=$HOME/a3

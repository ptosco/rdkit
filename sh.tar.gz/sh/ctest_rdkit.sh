source $HOME/sh/rdkit_build_env.sh
source ${CONDA}/etc/profile.d/conda.sh
conda activate rdkit_build
cd $HOME/build/rdkit
git_branch=`git rev-parse --abbrev-ref HEAD`
export RDBASE=`pwd`
export PYTHONPATH=$HOME/install/rdkit/$git_branch/lib/python3.7/site-packages:${PYTHONPATH}
export DYLD_FALLBACK_LIBRARY_PATH=$HOME/install/rdkit/$git_branch/lib:${CONDA_PREFIX}/lib:${DYLD_FALLBACK_LIBRARY_PATH}
export SDKROOT="${PWD}/MacOSX${target_platform}.sdk/"
export CONDA_BUILD_SYSROOT=${SDKROOT}
export QT_QPA_PLATFORM='offscreen'
cd build
ctest -j ${number_of_cores} --output-on-failure -T Test
